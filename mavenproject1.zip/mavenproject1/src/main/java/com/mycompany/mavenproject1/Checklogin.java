/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author win10 pro
 */
public class Checklogin {
    /* Login Check User Only
    String email = jTextField1.getText(); 
        String password = new String(jPasswordField1.getPassword()); 
                 try (BufferedReader reader = new BufferedReader(new FileReader(STORAGE_FILE))) {
                    String line;
                    boolean isValid = false; 
                    
                    while ((line = reader.readLine()) != null) { 
                        String[] parts = line.split(","); 
                        if (parts[0].equals(email) && parts[1].equals(password)) { 
                            isValid = true;
                            break;
                        }
                    }
                    
                    if (isValid) {
                        JOptionPane.showMessageDialog(null, "Login Successful!"); 
                        this.dispose(); 
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid email or password. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                 }catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error reading data!", "Error", JOptionPane.ERROR_MESSAGE);
                }
    */
    
    /*check detail in file. Combo with Login check
        
    private static final String STORAGE_FILE = "Storage.txt"; 
    private static final String ADMIN_EMAIL = "admin";       
    private static final String ADMIN_PASSWORD = "1234";  
    
     private static boolean isUserValid(String email, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader(STORAGE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(","); 
                if (parts.length == 2) {
                    String storedEmail = parts[0].trim(); 
                    String storedPassword = parts[1].trim(); 
                    if (email.equals(storedEmail) && password.equals(storedPassword)) {
                        return true; 
                    }
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error reading data file!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }*/
     
    /*login check Fixed Admin ID. Worked with User or Admin
    String email = jTextField1.getText(); 
        String password = new String(jPasswordField1.getPassword()); 
                 if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                    JOptionPane.showMessageDialog(this, "Welcome Admin!");
                    this.dispose(); 
                    openAdminPage();
                } else {
                    if (isUserValid(email, password)) {
                        JOptionPane.showMessageDialog(null, "Login Successful!"); 
                        this.dispose(); 
                        openUserPage();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Email or Password. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                 }*/
}
